from django.contrib import admin
from .models import *
 
admin.site.register(SoldProduct)
admin.site.register(MonthlyAdBudget)
admin.site.register(Package)
admin.site.register(Expense)
admin.site.register(Purchase)

 
 