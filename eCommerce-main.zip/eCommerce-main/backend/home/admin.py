from django.contrib import admin
from .models import  *
 
admin.site.register(Info)
admin.site.register(Slide)
admin.site.register(Deal)
admin.site.register(Card)
admin.site.register(BestSellers)
admin.site.register(GroupProduct)
admin.site.register(QuestionsGeneral)
admin.site.register(RateGeneral)







