from django.contrib import admin
from .models import *

admin.site.register(Dictionary)
admin.site.register(Region)
admin.site.register(City)
admin.site.register(shipping_Country)
admin.site.register(Shipping_Company)
admin.site.register(ShippingCompany_balance)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(Customers)
admin.site.register(DictionaryProductName)



