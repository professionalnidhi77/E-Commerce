from django.contrib import admin
from .models import  *

admin.site.register(Product)
admin.site.register(Category)
# admin.site.register(ThemeOne)
# admin.site.register(ThemeTwo)
# admin.site.register(ThemeThree)
admin.site.register(MoreInfo)
admin.site.register(Rate)
admin.site.register(Image_Product)
admin.site.register(FrequentlyAsked)

admin.site.register(Coupon)






 