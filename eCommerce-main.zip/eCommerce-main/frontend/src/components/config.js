const Config = {
  baseURL: 'https://smartcardnfc.com',
};

export default Config;