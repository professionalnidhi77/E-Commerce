import React from 'react';
import './Option.css';

export default function Option() {
  return (
    <div className='option'>
      <div className='new-option' >

        <div className='option_price'><div class="first-price">$49.00</div><div class="second-price"> $98.00 </div></div>
        <div className='option_title' >1 Google Review Card</div>
        <div option_img> <img className='IMG' src="https://thereviewguys.com.au/cdn/shop/files/TRG-Product-1_9bea83ec-c317-4ce5-a72d-c7668ba81536.png" /></div>
        <div className='option_checked'><span class="checked"></span></div>



      </div>
    </div>



  )
}
